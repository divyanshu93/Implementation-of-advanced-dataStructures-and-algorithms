
/**
 * @author divyanshu,aditya,radhika,shweta
 *
 */
public class Distance {
	int dist;
	boolean inf;

	public Distance(int distance, boolean infinity) {
		dist = distance;
		inf = infinity;
	}

}
