
public class ItemPrice implements Comparable {

	long id;
	double price;

	public ItemPrice(long id, double price) {
		this.id = id;
		this.price = price;
	}

	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}
