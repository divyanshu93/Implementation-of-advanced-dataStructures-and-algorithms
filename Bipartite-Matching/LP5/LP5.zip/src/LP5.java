import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class LP5 {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static boolean hasCycle;

	public static ArrayList<Vertex> freeInnerNodes = new ArrayList<>();

	// marking the nodes as unseen
	public static void markUnseen(Graph g) {
		for (Vertex v : g) {
			v.seen = false;
		}
	}

	// get the weight of the edge with vertex v1 and v2
	public static int getWeight(Vertex v1, Vertex v2) {
		for (Edge e : v1.Adj) {
			if (e.otherEnd(v1) == v2) {
				return e.Weight;
			}
		}
		return -1;
	}

	public static void printMatching(Graph g) {
		markUnseen(g);
		for (Vertex v : g) {
			if (!v.seen && v.mate != null) {
				System.out.println(v.name + "  " + v.mate.name + "  " + getWeight(v, v.mate));
				v.seen = true;
				v.mate.seen = true;
			}
		}
		markUnseen(g);
	}

	public static void dfs(Vertex v) {
		v.seen = true;
		for (Edge e : v.Adj) {
			Vertex u = e.otherEnd(v);
			if (!u.seen) {
				u.color = !v.color;// updating color of vertex u to mark it as
									// inner.
				// dfs(u);
			}
			// if the vertex and it's adjacent vertex have the same color then
			// we have got a cycle
			if (u.color == v.color) {
				hasCycle = true;
			}
		}
	}

	public static void checkBipartite(Graph g) {
		hasCycle = false;
		for (Vertex v : g) {
			if (v.seen == false) {
				dfs(v);
			}
		}
		for (Vertex v : g) {
			v.seen = false;
		}
	}

	// tree count
	static int count = 0;

	// size of the matching
	static int msize = 0;

	public static void maximumBipartiteMatching(Graph g) {

		ArrayList<Vertex> Q = new ArrayList<>();// a queue of the free outer
												// edges
		checkBipartite(g);
		if (hasCycle) {
			System.out.println("The graph is not Bipartite");
		} else {
			// Step 3
			for (Edge e : g.edges) {
				if (e.From.mate == null && e.To.mate == null) {
					e.From.mate = e.To;
					e.To.mate = e.From;
					msize++;
				}
			}
			int sizeInc = 0;
			// Step 4
			while (true) {

				// System.out.println("Starting");
				for (Vertex v : g) {
					v.seen = false;
					v.parent = null;
					v.freeze = false;
					// adding all the outer free nodes to the queue
					// False color means outer node and True means inner node
					if (v.mate == null && !v.color) {
						v.seen = true;
						Q.add(v);
						// System.out.println("Adding free outer node:" + v);
					}
				}

				while (Q.size() != 0) {
					Vertex u = Q.remove(0);
					// int flag = 1;
					// if (u.freeze)
					// continue;

					for (Edge e : u.Adj) {
						Vertex v = e.otherEnd(u);
						if (!v.seen && !v.freeze) {
							v.parent = u;
							v.seen = true;
							u.children.add(v);
							// got a free inner node
							if (v.mate == null) {
								// System.out.println("Got a free inner node:" +
								// v);
								v.tree = count;
								freeze(v, count++);// freeze the tree containing
													// free inner node
								freeInnerNodes.add(v);// add to a list of all
														// free inner nodes

								// flag = 0;
								// break;
								// freeze the tree
							} else {
								Vertex x = v.mate;
								x.seen = true;
								x.parent = v;
								// add the matched outer node to the queue
								Q.add(x);
								// System.out.println("Adding to the queue:" +
								// x);
								u.children.add(x);
							}
						}
					}
					// if (flag == 0) {
					// break;
					// }
				}

				int i = 0;// count of tree
				// process augmenting path for each tree starting from free
				// inner
				// nodes found
				// if (freeInnerNodes.size() > 0) {
				for (Vertex v : freeInnerNodes) {
					// System.out.println("free inner nodes:" + v);
					processAugmentingPath(v, i++);
				}
				if (sizeInc == msize) {// length of augmenting path
					break;
				}
				sizeInc = msize;
				System.out.println(msize);
			}

			int j = 0;
			for (Vertex u : g) {
				if (u.mate != null)
					j++;
			}
			System.out.println(j);
		}
	}

	public static void freeze(Vertex v, int count) {// we are iterating
													// correctly but where are
													// we freezing it? ==> Now
													// we will freeze everything
													// in the children list
		Vertex freeInnerNode = v;
		while (v.parent != null && v.tree != -1) {
			// if (v.freeze) {
			// alternateAugmenting(freeInnerNode);
			// freeInnerNodes.remove(freeInnerNode);
			// }
			// System.out.println("freezing you:" + v);
			// v.tree = count;
			v = v.parent;
		}
		// when it exits while loop, I will have the root node

		recursiveFreeze(v, count);

		// for (Vertex u : v.children) {
		// // System.out.println("coming here");
		// u.tree = count;
		// u.freeze = true;
		// if(u.children.size() > 0){
		//
		// }
		// }

		// dfs(v, count);

	}

	public static void alternateAugmenting(Vertex u) {
		Vertex v = u.parent;
		Vertex x = v.parent;
		u.mate = v;
		v.mate = u;
		x.mate = null;
		while (!x.parent.freeze) {
			Vertex nmx = x.parent;
			Vertex y = nmx.parent;
			nmx.mate = x;
			x.mate = nmx;
			x = y;
		}
	}

	public static void recursiveFreeze(Vertex v, int count) {

		if (v.tree != -1) {
			v.tree = count;
			v.freeze = true;
			for (Vertex u : v.children) {
				if (u.children.size() > 0)
					recursiveFreeze(u, count);
			}
		}

	}

	public static void dfs(Vertex v, int count) {// change logic here, tree = -1
													// is almost every time. We
													// need to update tree for
													// children correctly
		System.out.println("Never came inside");
		if (v.tree != -1) {
			v.tree = count;
			System.out.println("giving you a tree count:" + v.tree);
			for (Vertex u : v.children) {
				System.out.println("these are children of vertex:" + u);
				dfs(u, u.tree);
			}
		}

	}

	public static void processAugmentingPath(Vertex u, int i) {
		// free outer node
		Vertex p = u.parent;

		// parent of the free outer node
		Vertex x = p.parent;

		u.mate = p;
		p.mate = u;

		while (x != null) {// if we add x.tree != i using "or", it will throw
							// null pointer
							// exception when it reaches root node, we also need
							// to process the rest of the tree. Using "&&" it
							// will only trace till the root node, no further.
			Vertex nmx = x.parent;
			Vertex y = nmx.parent;
			x.mate = nmx;
			nmx.mate = x;
			x = y;
		}

		msize++;

	}

	public static void main(String[] args) throws FileNotFoundException {
		Scanner in;
		// flag used to show the matchings
		Boolean showmatching = true;
		if (args.length > 0) {
			if (args.length > 1)
				showmatching = true;
			File inputFile = new File(args[0]);
			in = new Scanner(inputFile);
		} else {
			in = new Scanner(System.in);
		}
		Graph g = Graph.readGraph(in, false);
		maximumBipartiteMatching(g);
		// if (showmatching)
		// printMatching(g);
	}

}